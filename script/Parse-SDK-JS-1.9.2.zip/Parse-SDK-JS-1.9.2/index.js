module.exports = require('./lib/browser/Parse.js');
