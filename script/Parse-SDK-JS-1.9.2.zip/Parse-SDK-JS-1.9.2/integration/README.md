## Integration tests

These tests run against a local instance of `parse-server`