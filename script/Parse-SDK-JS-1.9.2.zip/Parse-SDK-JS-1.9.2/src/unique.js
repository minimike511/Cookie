/**
 * Copyright (c) 2015-present, Parse, LLC.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 * @flow
 */

import arrayContainsObject from './arrayContainsObject';
import ParseObject from './ParseObject';

export default function unique<T>(arr: Array<T>): Array<T> {
  var uniques = [];
  arr.forEach((value) => {
    if (value instanceof ParseObject) {
      if (!arrayContainsObject(uniques, value)) {
        uniques.push(value);
      }
    } else {
      if (uniques.indexOf(value) < 0) {
        uniques.push(value);
      }
    }
  });
  return uniques;
}
